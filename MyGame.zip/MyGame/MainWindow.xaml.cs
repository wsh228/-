﻿using SharpGL;
using SharpGL.Enumerations;
using SharpGL.SceneGraph;
using SharpGL.SceneGraph.Assets;
using SharpGL.SceneGraph.Lighting;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OpenGL_1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void openGLControl_OpenGLInitialized(object sender, SharpGL.SceneGraph.OpenGLEventArgs args)
        {
            //  Get the OpenGL object.
            OpenGL gl = openGLControl.OpenGL;

            //  We need to load the texture from file.
            textureImage = new Bitmap(@"crate.bmp");

            //  A bit of extra initialisation here, we have to enable textures.
            gl.Enable(OpenGL.GL_TEXTURE_2D);

            //  Get one texture id, and stick it into the textures array.
            gl.GenTextures(1, textures);

            //  Bind the texture.
            gl.BindTexture(OpenGL.GL_TEXTURE_2D, textures[0]);

            //  Tell OpenGL where the texture data is.
            gl.TexImage2D(OpenGL.GL_TEXTURE_2D, 0, 3, textureImage.Width, textureImage.Height, 0, OpenGL.GL_BGR, OpenGL.GL_UNSIGNED_BYTE,
                textureImage.LockBits(new System.Drawing.Rectangle(0, 0, textureImage.Width, textureImage.Height),
                ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format24bppRgb).Scan0);

            //  Specify linear filtering.
            gl.TexParameter(OpenGL.GL_TEXTURE_2D, OpenGL.GL_TEXTURE_MIN_FILTER, OpenGL.GL_LINEAR);
            gl.TexParameter(OpenGL.GL_TEXTURE_2D, OpenGL.GL_TEXTURE_MAG_FILTER, OpenGL.GL_LINEAR);
        }

        private void openGLControl_Resized(object sender, SharpGL.SceneGraph.OpenGLEventArgs args)
        {
            //  Get the OpenGL object.
            OpenGL gl = openGLControl.OpenGL;

            //  Set the projection matrix.
            gl.MatrixMode(OpenGL.GL_PROJECTION);

            //  Load the identity.
            gl.LoadIdentity();

            //  Create a perspective transformation.
            gl.Perspective(60.0f, (double)Width / (double)Height, 0.01, 100.0);

            //  Use the 'look at' helper function to position and aim the camera.
            gl.LookAt(0, 5, -15, 0, 0, 0, 0, 1, 0);

            //  Set the modelview matrix.
            gl.MatrixMode(OpenGL.GL_MODELVIEW);
        }

        uint[] textures = new uint[1];

        //  Storage the texture itself.
        Bitmap textureImage;
         float yrot = 0.0f;
        
        public class ASD
        {
            int x, y, z;
            public void cord(int x, int y,int z)
            {
                this.x = x;
                this.y = y;
                this.z = z;
            }
            public void render(SharpGL.OpenGL gl, float yrot)
            {
                gl.PushMatrix();
                gl.Rotate(yrot, yrot*2, yrot*100, yrot*3);
                gl.Begin(OpenGL.GL_QUADS);

                // задница Face+
                gl.TexCoord(0.0f, 0.0f); gl.Vertex(-1.0f+x, -1.0f+y, 1.0f+z); // Bottom Left Of The Texture and Quad
                gl.TexCoord(0.0f, 1.0f); gl.Vertex(1.0f+x, -1.0f+y, 1.0f + z);  // Bottom Right Of The Texture and Quad
                gl.TexCoord(1.0f, 1.0f); gl.Vertex(1.0f+x, 1.0f+y, 1.0f + z);   // Top Right Of The Texture and Quad
                gl.TexCoord(1.0f, 0.0f); gl.Vertex(-1.0f+x, 1.0f + y, 1.0f + z);  // Top Left Of The Texture and Quad

                // лицо Face+
                gl.TexCoord(0.0f, 0.5f); gl.Vertex(-1.0f + x, -1.0f + y, -1.0f + z);    // Bottom Right Of The Texture and Quad
                gl.TexCoord(0.0f, 1.0f); gl.Vertex(-1.0f + x, 1.0f + y, -1.0f + z); // Top Right Of The Texture and Quad
                gl.TexCoord(0.5f, 1.0f); gl.Vertex(1.0f + x, 1.0f + y, -1.0f + z);  // Top Left Of The Texture and Quad
                gl.TexCoord(0.5f, 0.5f); gl.Vertex(1.0f + x, -1.0f + y, -1.0f + z); // Bottom Left Of The Texture and Quad

                // Top Face+
                gl.TexCoord(0.0f, 0.0f); gl.Vertex(-1.0f + x, 1.0f + y, -1.0f + z); // Top Left Of The Texture and Quad
                gl.TexCoord(0.0f, 0.5f); gl.Vertex(-1.0f + x, 1.0f + y, 1.0f + z);  // Bottom Left Of The Texture and Quad
                gl.TexCoord(0.5f, 0.5f); gl.Vertex(1.0f + x, 1.0f + y, 1.0f + z);   // Bottom Right Of The Texture and Quad
                gl.TexCoord(0.0f, 0.5f); gl.Vertex(1.0f + x, 1.0f + y, -1.0f + z);  // Top Right Of The Texture and Quad

                // Bottom Face+
                gl.TexCoord(0.5f, 0.5f); gl.Vertex(-1.0f + x, -1.0f + y, -1.0f + z);    // Top Right Of The Texture and Quad
                gl.TexCoord(0.5f, 1.0f); gl.Vertex(1.0f + x, -1.0f + y, -1.0f + z); // Top Left Of The Texture and Quad
                gl.TexCoord(1.0f, 1.0f); gl.Vertex(1.0f + x, -1.0f + y, 1.0f + z);  // Bottom Left Of The Texture and Quad
                gl.TexCoord(1.0f, 0.5f); gl.Vertex(-1.0f + x, -1.0f + y, 1.0f + z); // Bottom Right Of The Texture and Quad

                // левая face
                gl.TexCoord(0.5f, 0.5f); gl.Vertex(1.0f + x, - 1.0f + y, -1.0f + z); // Bottom Right Of The Texture and Quad
                gl.TexCoord(0.5f, 1.0f); gl.Vertex(1.0f + x, 1.0f + y, -1.0f + z);  // Top Right Of The Texture and Quad
                gl.TexCoord(1.0f, 1.0f); gl.Vertex(1.0f + x, 1.0f + y, 1.0f + z);   // Top Left Of The Texture and Quad
                gl.TexCoord(1.0f, 0.5f); gl.Vertex(1.0f + x, - 1.0f + y, 1.0f + z);  // Bottom Left Of The Texture and Quad

                // правая Face
                gl.TexCoord(0.5f, 0.5f); gl.Vertex(-1.0f + x, -1.0f + y, -1.0f + z);    // Bottom Left Of The Texture and Quad
                gl.TexCoord(0.5f, 1.0f); gl.Vertex(-1.0f + x, -1.0f + y, 1.0f + z); // Bottom Right Of The Texture and Quad
                gl.TexCoord(1.0f, 1.0f); gl.Vertex(-1.0f + x, 1.0f + y, 1.0f + z);  // Top Right Of The Texture and Quad
                gl.TexCoord(1.0f, 0.5f); gl.Vertex(-1.0f + x, 1.0f + y, -1.0f + z); // Top Left Of The Texture and Quad

                gl.End();
                gl.PopMatrix();
            }
        }
            
        
        

        private void openGLControl_OpenGLDraw(object sender, SharpGL.SceneGraph.OpenGLEventArgs args)
        {
            yrot += 1;

            //  Get the OpenGL object, for quick access.
            SharpGL.OpenGL gl = openGLControl.OpenGL;

           // gl.Rotate(4.0f, 0.0f, 5.0f, 0.0f);

            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);

            gl.BindTexture(OpenGL.GL_TEXTURE_2D, textures[0]);

            

            ASD a = new ASD();
            a.cord(0,3,0);
            a.render(openGLControl.OpenGL, yrot * 2);

            ASD a1 = new ASD();
            a1.cord(0, 0, 0);
            a1.render(openGLControl.OpenGL, yrot * 2);

            ASD a2 = new ASD();
            a2.cord(0, -3, 0);
            a2.render(openGLControl.OpenGL, yrot * 2);

            ASD a3 = new ASD();
            a3.cord(3, 0, 0);
            a3.render(openGLControl.OpenGL, yrot * 4);

            ASD a4 = new ASD();
            a4.cord(-3, 0, 0);
            a4.render(openGLControl.OpenGL, yrot * 4);



            gl.Flush();
        
        }
    }
}
